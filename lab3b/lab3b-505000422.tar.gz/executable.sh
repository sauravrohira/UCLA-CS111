#!/bin/sh

python lab3b.py $@